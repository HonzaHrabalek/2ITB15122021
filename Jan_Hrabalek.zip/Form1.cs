﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HrabálekJan
{
    public partial class Form1 : Form
    {
        Random rd = new Random();
        public int[] pole;
        public int even = 0;
        public Form1()
        {
            InitializeComponent();
            vytvorpole();
            naplnpole();
            logikapole();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void vytvorpole()
        {
            pole = new int[50];
        }

        public void naplnpole()
        {
            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rd.Next(10, 100);
            }
        }
        public int logikapole()
        {
            int vysledek = 0;
            for (int i = 0; i < pole.Length; i++)
            {
                if (pole[i] % 2 == 0)
                {
                    vysledek += pole[i];

                }
            }
            vysledek /= 10;
            return vysledek;
        }
    }
}